using FleetManagerPro.API.Models;

namespace FleetManagerPro.API.Data.Repository
{
    public interface IDriverRepository : IRepository<Driver>
    {
        Task<IEnumerable<Driver>> GetActiveDriversAsync()
        {
         return await _context.Drivers
        .Where(d => d.IsAvailable) // or `d.Status == UserStatus.Active` depending on your model
        .ToListAsync();
        }
    }
}
