using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FleetManagerPro.API.Models
{
    [Table("drivers")]
    public class Driver
    {
        [Key]
        [StringLength(128)]
        [ForeignKey("User")]
        public string UserId { get; set; } = string.Empty;

        [Required]
        [StringLength(50)]
        public string LicenseNumber { get; set; } = string.Empty;

        [Required]
        [StringLength(20)]
        public string LicenseClass { get; set; } = string.Empty;

        public DateTime LicenseExpiry { get; set; }

        public int ExperienceYears { get; set; }

        public long TotalMilesDriven { get; set; }

        public double SafetyRating { get; set; }

        public string? CurrentVehicleId { get; set; }

        public bool IsAvailable { get; set; }

        public double? LastLocationLat { get; set; }

        public double? LastLocationLng { get; set; }

        public DateTime? LastLocationUpdated { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [Column("updated_at")]
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

        // Navigation properties
        public virtual User User { get; set; } = null!;
        public virtual Vehicle? CurrentVehicle { get; set; }
        public virtual ICollection<Route> Routes { get; set; } = new List<Route>();
        public virtual ICollection<DriverAttendance> AttendanceRecords { get; set; } = new List<DriverAttendance>();
        public virtual ICollection<LeaveRequest> LeaveRequests { get; set; } = new List<LeaveRequest>();
    }
}
